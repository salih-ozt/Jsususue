import { useState, useEffect } from "react";
import { Plus, Loader2 } from "lucide-react";
import { getStories, getStoredUser } from "@/lib/api";
import StoryViewer from "./StoryViewer";

interface Story {
  id: string;
  userId: string;
  username: string;
  profilePic?: string;
  mediaUrl: string;
  createdAt: string;
  viewed?: boolean;
}

interface StoryGroup {
  userId: string;
  username: string;
  profilePic?: string;
  stories: Story[];
  hasUnviewed: boolean;
}

const StoriesBar = () => {
  const [groups, setGroups] = useState<StoryGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewingGroup, setViewingGroup] = useState<StoryGroup | null>(null);
  const currentUser = getStoredUser();

  useEffect(() => {
    loadStories();
  }, []);

  const loadStories = async () => {
    try {
      const data = await getStories();
      const stories: Story[] = data.stories || [];
      
      // Group by user
      const map = new Map<string, StoryGroup>();
      stories.forEach((s) => {
        if (!map.has(s.userId)) {
          map.set(s.userId, {
            userId: s.userId,
            username: s.username,
            profilePic: s.profilePic,
            stories: [],
            hasUnviewed: false,
          });
        }
        const g = map.get(s.userId)!;
        g.stories.push(s);
        if (!s.viewed) g.hasUnviewed = true;
      });
      setGroups(Array.from(map.values()));
    } catch {
      // Silently fail
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-4">
        <Loader2 className="w-5 h-5 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide px-4 py-3">
        {/* My story */}
        <button className="flex flex-col items-center gap-1 flex-shrink-0">
          <div className="relative w-16 h-16">
            <img
              src={currentUser?.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${currentUser?.username || "me"}&backgroundColor=0a1628`}
              alt="Sen"
              className="w-16 h-16 rounded-full object-cover border-2 border-border"
            />
            <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full bg-primary flex items-center justify-center border-2 border-card">
              <Plus className="w-3 h-3 text-primary-foreground" />
            </div>
          </div>
          <span className="text-[10px] text-muted-foreground font-medium">Hikaye</span>
        </button>

        {/* Others */}
        {groups.map((g) => {
          const avatar = g.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${g.username}&backgroundColor=0a1628`;
          return (
            <button
              key={g.userId}
              onClick={() => setViewingGroup(g)}
              className="flex flex-col items-center gap-1 flex-shrink-0"
            >
              <div
                className={`w-16 h-16 rounded-full p-[2px] ${
                  g.hasUnviewed
                    ? "bg-gradient-to-tr from-primary to-accent"
                    : "bg-muted-foreground/30"
                }`}
              >
                <img
                  src={avatar}
                  alt={g.username}
                  className="w-full h-full rounded-full object-cover border-2 border-card"
                />
              </div>
              <span className="text-[10px] text-muted-foreground font-medium truncate w-16 text-center">
                {g.username}
              </span>
            </button>
          );
        })}
      </div>

      {viewingGroup && (
        <StoryViewer
          group={viewingGroup}
          onClose={() => setViewingGroup(null)}
        />
      )}
    </>
  );
};

export default StoriesBar;
