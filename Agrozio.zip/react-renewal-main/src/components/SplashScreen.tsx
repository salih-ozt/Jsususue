import { useEffect, useState } from "react";
import { Sprout } from "lucide-react";

interface Props {
  onComplete: () => void;
}

const SplashScreen = ({ onComplete }: Props) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 300);
          return 100;
        }
        return p + 4;
      });
    }, 50);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center gap-8 bg-gradient-to-br from-background via-card to-background">
      {/* Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1.5 h-1.5 bg-primary/50 rounded-full"
            style={{
              left: `${[10, 20, 80, 70, 50, 30][i]}%`,
              top: `${[20, 80, 15, 70, 50, 60][i]}%`,
              animation: `dotBounce 2s ease-in-out ${i * 0.4}s infinite`,
            }}
          />
        ))}
      </div>

      {/* Logo */}
      <div className="w-24 h-24 rounded-3xl agro-gradient flex items-center justify-center shadow-agro animate-scale-in">
        <Sprout className="w-12 h-12 text-primary-foreground" />
      </div>

      {/* Text */}
      <div className="text-center">
        <h2 className="text-3xl font-extrabold agro-gradient-text">Agro Sosyal</h2>
        <p className="text-muted-foreground text-sm mt-2 animate-fade-in">
          Tarımın dijital buluşma noktası
        </p>
      </div>

      {/* Loading dots */}
      <div className="flex gap-2">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="w-2.5 h-2.5 bg-primary rounded-full"
            style={{ animation: `dotBounce 1.4s ease-in-out ${i * 0.2}s infinite` }}
          />
        ))}
      </div>

      {/* Progress bar */}
      <div className="w-48 h-1 bg-muted rounded-full overflow-hidden">
        <div
          className="h-full agro-gradient rounded-full transition-all duration-100"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

export default SplashScreen;
