import { useState } from "react";
import { Heart, MessageCircle, Bookmark, MoreHorizontal, Share2 } from "lucide-react";
import { likePost, savePost } from "@/lib/api";
import CommentsModal from "./CommentsModal";

interface PostData {
  id: string;
  name?: string;
  username?: string;
  authorUsername?: string;
  profilePic?: string;
  media?: string;
  mediaUrl?: string;
  mediaUrls?: string[];
  content?: string;
  likeCount: number;
  commentCount: number;
  isLiked: boolean;
  isSaved?: boolean;
  createdAt: string;
  mediaType?: string;
}

const PostCard = ({ post }: { post: PostData }) => {
  const [liked, setLiked] = useState(post.isLiked);
  const [saved, setSaved] = useState(post.isSaved || false);
  const [likes, setLikes] = useState(post.likeCount || 0);
  const [showComments, setShowComments] = useState(false);
  const [heartAnim, setHeartAnim] = useState(false);
  const [carouselIdx, setCarouselIdx] = useState(0);

  const toggleLike = async () => {
    const prev = liked;
    setLiked(!liked);
    setLikes(liked ? likes - 1 : likes + 1);
    if (!liked) {
      setHeartAnim(true);
      setTimeout(() => setHeartAnim(false), 600);
    }
    try {
      const data = await likePost(post.id);
      setLiked(data.liked);
    } catch {
      setLiked(prev);
      setLikes(prev ? likes : likes - 1);
    }
  };

  const toggleSave = async () => {
    setSaved(!saved);
    try {
      await savePost(post.id);
    } catch {
      setSaved(!saved);
    }
  };

  const handleDoubleTap = () => {
    if (!liked) toggleLike();
    else {
      setHeartAnim(true);
      setTimeout(() => setHeartAnim(false), 600);
    }
  };

  const displayName = post.authorUsername || post.username || "user";
  const avatar = post.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${displayName}&backgroundColor=0a1628`;
  const mediaItems = post.mediaUrls || (post.mediaUrl || post.media ? [post.mediaUrl || post.media] : []);
  const timeAgo = formatTimeAgo(post.createdAt);

  return (
    <>
      <div className="bg-card border border-border rounded-2xl overflow-hidden animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-3 p-4">
          <img src={avatar} alt={displayName} className="w-10 h-10 rounded-full object-cover ring-2 ring-primary/30" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground">{displayName}</p>
            <p className="text-xs text-muted-foreground">{timeAgo}</p>
          </div>
          <button className="text-muted-foreground p-1">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Media Carousel */}
        {mediaItems.length > 0 && post.mediaType !== "text" && (
          <div className="relative" onDoubleClick={handleDoubleTap}>
            <div className="overflow-hidden">
              <div
                className="flex transition-transform duration-300 ease-out"
                style={{ transform: `translateX(-${carouselIdx * 100}%)` }}
              >
                {mediaItems.map((url, i) => (
                  <img
                    key={i}
                    src={url}
                    alt=""
                    className="w-full flex-shrink-0 max-h-[560px] min-h-[200px] object-cover bg-muted"
                  />
                ))}
              </div>
            </div>

            {/* Carousel controls */}
            {mediaItems.length > 1 && (
              <>
                {carouselIdx > 0 && (
                  <button
                    onClick={() => setCarouselIdx(carouselIdx - 1)}
                    className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/60 backdrop-blur flex items-center justify-center text-foreground"
                  >
                    ‹
                  </button>
                )}
                {carouselIdx < mediaItems.length - 1 && (
                  <button
                    onClick={() => setCarouselIdx(carouselIdx + 1)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/60 backdrop-blur flex items-center justify-center text-foreground"
                  >
                    ›
                  </button>
                )}
                <div className="absolute top-2.5 right-2.5 bg-background/60 backdrop-blur px-2 py-0.5 rounded-full text-xs font-bold text-foreground">
                  {carouselIdx + 1}/{mediaItems.length}
                </div>
                <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex gap-1.5">
                  {mediaItems.map((_, i) => (
                    <div
                      key={i}
                      className={`h-1.5 rounded-full transition-all ${
                        i === carouselIdx ? "w-4 bg-foreground" : "w-1.5 bg-foreground/40"
                      }`}
                    />
                  ))}
                </div>
              </>
            )}

            {/* Heart animation */}
            {heartAnim && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <Heart className="w-20 h-20 text-destructive fill-destructive animate-heart-beat" />
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-4">
              <button onClick={toggleLike} className="flex items-center gap-1.5 group active:scale-90 transition-transform">
                <Heart
                  className={`w-6 h-6 transition-all ${
                    liked ? "fill-destructive text-destructive" : "text-muted-foreground group-hover:text-foreground"
                  }`}
                />
                <span className="text-sm text-muted-foreground">{likes}</span>
              </button>
              <button onClick={() => setShowComments(true)} className="flex items-center gap-1.5 group active:scale-90 transition-transform">
                <MessageCircle className="w-6 h-6 text-muted-foreground group-hover:text-foreground transition-colors" />
                <span className="text-sm text-muted-foreground">{post.commentCount || 0}</span>
              </button>
              <button className="active:scale-90 transition-transform">
                <Share2 className="w-5 h-5 text-muted-foreground hover:text-foreground transition-colors" />
              </button>
            </div>
            <button onClick={toggleSave} className="active:scale-90 transition-transform">
              <Bookmark
                className={`w-6 h-6 transition-all ${
                  saved ? "fill-primary text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              />
            </button>
          </div>

          {post.content && (
            <p className="text-sm text-foreground leading-relaxed">
              <span className="font-semibold">{displayName}</span>{" "}
              {post.content}
            </p>
          )}

          {(post.commentCount || 0) > 0 && (
            <button
              onClick={() => setShowComments(true)}
              className="text-xs text-muted-foreground mt-2"
            >
              {post.commentCount} yorumun tümünü gör
            </button>
          )}
        </div>
      </div>

      <CommentsModal
        postId={post.id}
        open={showComments}
        onClose={() => setShowComments(false)}
      />
    </>
  );
};

function formatTimeAgo(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
  if (diff < 60) return "az önce";
  if (diff < 3600) return `${Math.floor(diff / 60)}dk`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}sa`;
  return `${Math.floor(diff / 86400)}g`;
}

export default PostCard;
