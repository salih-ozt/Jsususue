import { Home, Search, PlusSquare, Bell, User } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";

const tabs = [
  { icon: Home, path: "/feed", label: "Ana Sayfa" },
  { icon: Search, path: "/search", label: "Keşfet" },
  { icon: PlusSquare, path: "/create", label: "Paylaş" },
  { icon: Bell, path: "/notifications", label: "Bildirim" },
  { icon: User, path: "/profile", label: "Profil" },
];

const BottomNav = () => {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <nav className="fixed bottom-0 left-0 right-0 glass border-t border-border z-50">
      <div className="max-w-lg mx-auto flex items-center justify-around py-1.5">
        {tabs.map(({ icon: Icon, path, label }) => {
          const active = location.pathname === path;
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className={`flex flex-col items-center gap-0.5 p-2 rounded-xl transition-all active:scale-90 ${
                active ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <Icon className={`w-6 h-6 ${active ? "drop-shadow-[0_0_8px_hsl(var(--primary)/0.5)]" : ""}`} />
              <span className="text-[10px] font-medium">{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
