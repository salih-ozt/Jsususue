import { useState } from "react";
import { X, Loader2, Camera } from "lucide-react";
import { updateProfile, setStoredUser } from "@/lib/api";

interface Props {
  user: any;
  open: boolean;
  onClose: () => void;
  onUpdated: (data: any) => void;
}

const EditProfileModal = ({ user, open, onClose, onUpdated }: Props) => {
  const [name, setName] = useState(user?.name || "");
  const [bio, setBio] = useState(user?.bio || "");
  const [city, setCity] = useState(user?.city || "");
  const [avatar, setAvatar] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setAvatar(f);
      setAvatarPreview(URL.createObjectURL(f));
    }
  };

  const handleSave = async () => {
    setLoading(true);
    setError("");
    try {
      const formData = new FormData();
      formData.append("name", name);
      formData.append("bio", bio);
      formData.append("city", city);
      if (avatar) formData.append("profilePic", avatar);
      const data = await updateProfile(formData);
      if (data.error) { setError(data.error); return; }
      const updated = { name, bio, city, ...(data.user || {}) };
      setStoredUser({ ...user, ...updated });
      onUpdated(updated);
      onClose();
    } catch { setError("Güncelleme başarısız"); }
    finally { setLoading(false); }
  };

  if (!open) return null;

  const currentAvatar = avatarPreview || user?.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${user?.username}&backgroundColor=0a1628`;
  const inputClass = "w-full px-4 py-3 rounded-xl bg-muted border border-border text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm";

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center">
      <div className="absolute inset-0 bg-background/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-card rounded-t-3xl border border-border border-b-0 animate-slide-up">
        <div className="flex items-center justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
        </div>

        <div className="flex items-center justify-between px-4 pb-3 border-b border-border">
          <h3 className="text-base font-bold text-foreground">Profili Düzenle</h3>
          <button onClick={onClose} className="p-1 text-muted-foreground"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-4 space-y-4 max-h-[70vh] overflow-y-auto scrollbar-hide">
          {/* Avatar */}
          <div className="flex justify-center">
            <label className="relative cursor-pointer">
              <img src={currentAvatar} alt="" className="w-20 h-20 rounded-full object-cover" />
              <div className="absolute bottom-0 right-0 w-7 h-7 rounded-full agro-gradient flex items-center justify-center border-2 border-card">
                <Camera className="w-3.5 h-3.5 text-primary-foreground" />
              </div>
              <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
            </label>
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Ad Soyad</label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Biyografi</label>
            <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} className={`${inputClass} resize-none`} placeholder="Kendinden bahset..." />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Şehir</label>
            <input type="text" value={city} onChange={(e) => setCity(e.target.value)} className={inputClass} placeholder="İstanbul" />
          </div>

          {error && <p className="text-destructive text-xs text-center">{error}</p>}

          <button
            onClick={handleSave}
            disabled={loading}
            className="w-full py-3 rounded-xl agro-gradient text-primary-foreground font-semibold text-sm active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-agro"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            Kaydet
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditProfileModal;
