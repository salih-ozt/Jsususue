import { useState, useEffect, useCallback } from "react";
import { X } from "lucide-react";
import { markStoryViewed } from "@/lib/api";

interface Story {
  id: string;
  mediaUrl: string;
  createdAt: string;
  viewed?: boolean;
}

interface StoryGroup {
  userId: string;
  username: string;
  profilePic?: string;
  stories: Story[];
}

interface Props {
  group: StoryGroup;
  onClose: () => void;
}

const StoryViewer = ({ group, onClose }: Props) => {
  const [idx, setIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const story = group.stories[idx];

  const next = useCallback(() => {
    if (idx < group.stories.length - 1) {
      setIdx(idx + 1);
      setProgress(0);
    } else {
      onClose();
    }
  }, [idx, group.stories.length, onClose]);

  const prev = () => {
    if (idx > 0) {
      setIdx(idx - 1);
      setProgress(0);
    }
  };

  useEffect(() => {
    if (story && !story.viewed) {
      markStoryViewed(story.id).catch(() => {});
    }
  }, [story]);

  useEffect(() => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          next();
          return 0;
        }
        return p + 2;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [idx, next]);

  const avatar = group.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${group.username}&backgroundColor=0a1628`;

  return (
    <div className="fixed inset-0 z-[200] bg-background flex items-center justify-center">
      <div className="relative w-full max-w-lg h-full max-h-[100dvh] bg-background">
        {/* Progress bars */}
        <div className="absolute top-2 left-2 right-2 z-20 flex gap-1">
          {group.stories.map((_, i) => (
            <div key={i} className="flex-1 h-0.5 bg-foreground/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-foreground rounded-full transition-all duration-100"
                style={{
                  width: i < idx ? "100%" : i === idx ? `${progress}%` : "0%",
                }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-6 left-0 right-0 z-20 flex items-center gap-3 px-4">
          <img src={avatar} alt="" className="w-8 h-8 rounded-full object-cover" />
          <span className="text-sm font-semibold text-foreground">{group.username}</span>
          <span className="text-xs text-muted-foreground">
            {new Date(story?.createdAt).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}
          </span>
          <button onClick={onClose} className="ml-auto text-foreground">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Story media */}
        <img
          src={story?.mediaUrl}
          alt=""
          className="w-full h-full object-contain"
        />

        {/* Touch areas */}
        <div className="absolute inset-0 flex z-10">
          <div className="w-1/3 h-full" onClick={prev} />
          <div className="w-1/3 h-full" />
          <div className="w-1/3 h-full" onClick={next} />
        </div>
      </div>
    </div>
  );
};

export default StoryViewer;
