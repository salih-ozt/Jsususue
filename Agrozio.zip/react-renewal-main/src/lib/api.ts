const API_BASE = "https://sehitumitkestitarimmtal.com/api";

function getToken(): string | null {
  return localStorage.getItem("agrolink_token");
}

export function setToken(token: string) {
  localStorage.setItem("agrolink_token", token);
}

export function setRefreshToken(token: string) {
  localStorage.setItem("agrolink_refresh_token", token);
}

export function clearAuth() {
  localStorage.removeItem("agrolink_token");
  localStorage.removeItem("agrolink_refresh_token");
  localStorage.removeItem("agrolink_user");
}

export function getStoredUser() {
  const u = localStorage.getItem("agrolink_user");
  return u ? JSON.parse(u) : null;
}

export function setStoredUser(user: any) {
  localStorage.setItem("agrolink_user", JSON.stringify(user));
}

export function isAuthenticated(): boolean {
  return !!getToken();
}

async function apiFetch(path: string, options: RequestInit = {}) {
  const token = getToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> || {}),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  if (!(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });

  if (res.status === 401) {
    const refreshed = await tryRefresh();
    if (refreshed) {
      headers["Authorization"] = `Bearer ${getToken()}`;
      const retry = await fetch(`${API_BASE}${path}`, { ...options, headers });
      return retry;
    }
    clearAuth();
    window.location.href = "/login";
    throw new Error("Unauthorized");
  }

  return res;
}

async function tryRefresh(): Promise<boolean> {
  const rt = localStorage.getItem("agrolink_refresh_token");
  if (!rt) return false;
  try {
    const res = await fetch(`${API_BASE}/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refreshToken: rt }),
    });
    if (!res.ok) return false;
    const data = await res.json();
    setToken(data.token);
    if (data.refreshToken) setRefreshToken(data.refreshToken);
    return true;
  } catch {
    return false;
  }
}

// Auth
export async function login(identifier: string, password: string) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identifier, password }),
  });
  return res.json();
}

export async function register(data: { name: string; username: string; email: string; password: string; birthDate?: string; city?: string }) {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function verify2FA(tempToken: string, code: string) {
  const res = await fetch(`${API_BASE}/auth/verify-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tempToken, code }),
  });
  return res.json();
}

export async function verifyEmailCode(tempToken: string, code: string) {
  const res = await fetch(`${API_BASE}/auth/verify-email`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tempToken, code }),
  });
  return res.json();
}

export async function forgotPassword(email: string) {
  const res = await fetch(`${API_BASE}/auth/forgot-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });
  return res.json();
}

export async function resetPassword(token: string, password: string) {
  const res = await fetch(`${API_BASE}/auth/reset-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token, password }),
  });
  return res.json();
}

// Feed
export async function getFeed(page = 1, limit = 20) {
  const res = await apiFetch(`/feed?page=${page}&limit=${limit}`);
  return res.json();
}

// Profile
export async function getMe() {
  const res = await apiFetch("/me");
  return res.json();
}

export async function getUserProfile(idOrUsername: string) {
  const res = await apiFetch(`/users/${idOrUsername}`);
  return res.json();
}

export async function getUserPosts(userId: string, page = 1) {
  const res = await apiFetch(`/users/${userId}/posts?page=${page}`);
  return res.json();
}

export async function updateProfile(formData: FormData) {
  const token = getToken();
  const res = await fetch(`${API_BASE}/me/update`, {
    method: "PUT",
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });
  return res.json();
}

// Posts
export async function likePost(postId: string) {
  const res = await apiFetch(`/posts/${postId}/like`, { method: "POST" });
  return res.json();
}

export async function savePost(postId: string) {
  const res = await apiFetch(`/posts/${postId}/save`, { method: "POST" });
  return res.json();
}

export async function deletePost(postId: string) {
  const res = await apiFetch(`/posts/${postId}`, { method: "DELETE" });
  return res.json();
}

export async function reportPost(postId: string, reason: string) {
  const res = await apiFetch(`/posts/${postId}/report`, {
    method: "POST",
    body: JSON.stringify({ reason }),
  });
  return res.json();
}

export async function getPostComments(postId: string, page = 1) {
  const res = await apiFetch(`/posts/${postId}/comments?page=${page}`);
  return res.json();
}

export async function addComment(postId: string, content: string) {
  const res = await apiFetch(`/posts/${postId}/comments`, {
    method: "POST",
    body: JSON.stringify({ content }),
  });
  return res.json();
}

export async function createPost(formData: FormData) {
  const token = getToken();
  const res = await fetch(`${API_BASE}/posts`, {
    method: "POST",
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });
  return res.json();
}

// Messages
export async function getConversations() {
  const res = await apiFetch("/messages/conversations");
  return res.json();
}

export async function getMessages(userId: string, page = 1) {
  const res = await apiFetch(`/messages/${userId}?page=${page}&limit=50`);
  return res.json();
}

export async function sendMessage(recipientId: string, content: string) {
  const res = await apiFetch("/messages", {
    method: "POST",
    body: JSON.stringify({ recipientId, content }),
  });
  return res.json();
}

// Follow
export async function toggleFollow(userId: string) {
  const res = await apiFetch(`/users/${userId}/follow`, { method: "POST" });
  return res.json();
}

// Notifications
export async function getNotifications(page = 1) {
  const res = await apiFetch(`/notifications?page=${page}`);
  return res.json();
}

export async function markNotificationsRead() {
  const res = await apiFetch("/notifications/read-all", { method: "POST" });
  return res.json();
}

// Search
export async function searchUsers(query: string) {
  const res = await apiFetch(`/search/users?q=${encodeURIComponent(query)}`);
  return res.json();
}

export async function searchPosts(query: string) {
  const res = await apiFetch(`/search/posts?q=${encodeURIComponent(query)}`);
  return res.json();
}

// Stories
export async function getStories() {
  const res = await apiFetch("/stories");
  return res.json();
}

export async function createStory(formData: FormData) {
  const token = getToken();
  const res = await fetch(`${API_BASE}/stories`, {
    method: "POST",
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });
  return res.json();
}

export async function markStoryViewed(storyId: string) {
  const res = await apiFetch(`/stories/${storyId}/view`, { method: "POST" });
  return res.json();
}

// Store
export async function getStoreItems(page = 1, category?: string) {
  let url = `/store?page=${page}`;
  if (category) url += `&category=${encodeURIComponent(category)}`;
  const res = await apiFetch(url);
  return res.json();
}

export async function logout() {
  try {
    await apiFetch("/auth/logout", { method: "POST" });
  } catch {}
  clearAuth();
}
