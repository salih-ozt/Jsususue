import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ImagePlus, X, Loader2, Film } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { createPost } from "@/lib/api";

const CreatePostPage = () => {
  const navigate = useNavigate();
  const [caption, setCaption] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<{ url: string; type: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files || []);
    const combined = [...files, ...selected].slice(0, 10);
    setFiles(combined);
    setPreviews(combined.map((f) => ({
      url: URL.createObjectURL(f),
      type: f.type.startsWith("video") ? "video" : "image",
    })));
  };

  const removeFile = (idx: number) => {
    const newFiles = files.filter((_, i) => i !== idx);
    setFiles(newFiles);
    setPreviews(newFiles.map((f) => ({
      url: URL.createObjectURL(f),
      type: f.type.startsWith("video") ? "video" : "image",
    })));
  };

  const handleShare = async () => {
    if (files.length === 0 && !caption.trim()) return;
    setLoading(true);
    setError("");
    try {
      const formData = new FormData();
      files.forEach((f) => formData.append("media", f));
      if (caption.trim()) formData.append("content", caption);
      const data = await createPost(formData);
      if (data.error) { setError(data.error); return; }
      navigate("/feed");
    } catch { setError("Gönderi paylaşılamadı"); }
    finally { setLoading(false); }
  };

  const gridClass = previews.length === 1 ? "grid-cols-1" : previews.length <= 4 ? "grid-cols-2" : "grid-cols-3";

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 glass border-b border-border">
        <div className="max-w-lg mx-auto flex items-center justify-between h-14 px-4">
          <h1 className="text-lg font-bold text-foreground">Yeni Gönderi</h1>
          <button
            onClick={handleShare}
            disabled={loading || (files.length === 0 && !caption.trim())}
            className="text-sm font-semibold text-primary disabled:text-muted-foreground transition-colors flex items-center gap-1"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            Paylaş
          </button>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-4">
        {error && <p className="text-destructive text-sm text-center">{error}</p>}

        {previews.length > 0 ? (
          <div className={`grid ${gridClass} gap-1 rounded-2xl overflow-hidden`}>
            {previews.map((p, i) => (
              <div key={i} className="relative aspect-square bg-muted">
                {p.type === "video" ? (
                  <video src={p.url} className="w-full h-full object-cover" />
                ) : (
                  <img src={p.url} alt="" className="w-full h-full object-cover" />
                )}
                <button
                  onClick={() => removeFile(i)}
                  className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-background/70 backdrop-blur flex items-center justify-center"
                >
                  <X className="w-3 h-3 text-foreground" />
                </button>
                <span className="absolute bottom-1.5 left-1.5 bg-background/60 text-foreground text-[9px] px-1.5 py-0.5 rounded-md font-bold">
                  {p.type === "video" ? "VİDEO" : "FOTO"}
                </span>
              </div>
            ))}
            {previews.length < 10 && (
              <label className="aspect-square border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-1 cursor-pointer bg-muted/50 hover:border-primary/50 transition-colors">
                <ImagePlus className="w-6 h-6 text-muted-foreground" />
                <span className="text-[10px] text-muted-foreground">Ekle</span>
                <input type="file" accept="image/*,video/*" multiple onChange={handleFileSelect} className="hidden" />
              </label>
            )}
          </div>
        ) : (
          <label className="flex flex-col items-center justify-center w-full aspect-square rounded-2xl border-2 border-dashed border-border bg-muted/50 cursor-pointer hover:border-primary/50 transition-colors">
            <div className="flex items-center gap-4 mb-3">
              <ImagePlus className="w-10 h-10 text-muted-foreground" />
              <Film className="w-10 h-10 text-muted-foreground" />
            </div>
            <span className="text-sm text-muted-foreground">Fotoğraf veya video ekleyin</span>
            <span className="text-xs text-muted-foreground/50 mt-1">En fazla 10 dosya</span>
            <input type="file" accept="image/*,video/*" multiple onChange={handleFileSelect} className="hidden" />
          </label>
        )}

        <textarea
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="Bir şeyler yaz..."
          rows={4}
          className="w-full px-4 py-3 rounded-xl bg-muted border border-border text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none transition-all text-sm"
        />
      </main>

      <BottomNav />
    </div>
  );
};

export default CreatePostPage;
