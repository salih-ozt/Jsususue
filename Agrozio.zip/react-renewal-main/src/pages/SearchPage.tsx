import { useState, useCallback } from "react";
import { Search, Loader2, UserPlus, Check } from "lucide-react";
import { useNavigate } from "react-router-dom";
import BottomNav from "@/components/BottomNav";
import { searchUsers, toggleFollow } from "@/lib/api";

const SearchPage = () => {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = useCallback(async (q: string) => {
    if (q.trim().length < 2) { setResults([]); setSearched(false); return; }
    setLoading(true);
    setSearched(true);
    try {
      const data = await searchUsers(q);
      setResults(data.users || []);
    } catch { setResults([]); }
    setLoading(false);
  }, []);

  const handleFollow = async (userId: string, idx: number) => {
    const prev = results[idx]._followed;
    setResults((r) => r.map((u, i) => i === idx ? { ...u, _followed: !prev } : u));
    try {
      await toggleFollow(userId);
    } catch {
      setResults((r) => r.map((u, i) => i === idx ? { ...u, _followed: prev } : u));
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 glass border-b border-border">
        <div className="max-w-lg mx-auto px-4 py-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => { setQuery(e.target.value); handleSearch(e.target.value); }}
              placeholder="Kullanıcı ara..."
              className="w-full pl-10 pr-4 py-3 rounded-2xl bg-muted border border-border text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm"
            />
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : results.length === 0 && searched ? (
          <div className="text-center py-20 space-y-3">
            <Search className="w-12 h-12 text-muted-foreground mx-auto" />
            <p className="text-muted-foreground text-sm">Kullanıcı bulunamadı</p>
          </div>
        ) : !searched ? (
          <div className="text-center py-20 space-y-3">
            <Search className="w-12 h-12 text-muted-foreground/30 mx-auto" />
            <p className="text-muted-foreground text-sm">Çiftçi arkadaşlarını bul</p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {results.map((user, i) => {
              const avatar = user.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${user.username}&backgroundColor=0a1628`;
              return (
                <div key={user.id} className="flex items-center gap-3 px-4 py-3">
                  <img
                    src={avatar}
                    alt={user.username}
                    className="w-12 h-12 rounded-full object-cover cursor-pointer"
                    onClick={() => navigate(`/user/${user.id}`)}
                  />
                  <div className="flex-1 min-w-0" onClick={() => navigate(`/user/${user.id}`)}>
                    <p className="text-sm font-semibold text-foreground">{user.name || user.username}</p>
                    <p className="text-xs text-muted-foreground">@{user.username}</p>
                  </div>
                  <button
                    onClick={() => handleFollow(user.id, i)}
                    className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-95 ${
                      user._followed
                        ? "bg-secondary text-secondary-foreground"
                        : "agro-gradient text-primary-foreground shadow-agro"
                    }`}
                  >
                    {user._followed ? (
                      <span className="flex items-center gap-1"><Check className="w-3 h-3" /> Takip</span>
                    ) : (
                      <span className="flex items-center gap-1"><UserPlus className="w-3 h-3" /> Takip Et</span>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default SearchPage;
