import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sprout, Loader2, Eye, EyeOff, ArrowLeft, ArrowRight } from "lucide-react";
import { login, register, verify2FA, verifyEmailCode, forgotPassword, setToken, setRefreshToken, setStoredUser } from "@/lib/api";

type AuthView = "login" | "register-1" | "register-2" | "forgot" | "2fa" | "email-verify";

const LoginPage = () => {
  const navigate = useNavigate();
  const [view, setView] = useState<AuthView>("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPw, setShowPw] = useState(false);

  // Login
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");

  // Register step 1
  const [regName, setRegName] = useState("");
  const [regUsername, setRegUsername] = useState("");
  const [regEmail, setRegEmail] = useState("");

  // Register step 2
  const [regPassword, setRegPassword] = useState("");
  const [regPasswordConfirm, setRegPasswordConfirm] = useState("");
  const [regBirthDate, setRegBirthDate] = useState("");
  const [regCity, setRegCity] = useState("");

  // 2FA / Email verify
  const [tempToken, setTempToken] = useState("");
  const [otpCode, setOtpCode] = useState("");

  // Forgot password
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotSent, setForgotSent] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier || !password) { setError("Lütfen tüm alanları doldurun"); return; }
    setError(""); setLoading(true);
    try {
      const data = await login(identifier, password);
      if (data.error) { setError(data.error); return; }
      if (data.requires2FA) {
        setTempToken(data.tempToken);
        setView("2fa");
        return;
      }
      setToken(data.token);
      if (data.refreshToken) setRefreshToken(data.refreshToken);
      if (data.user) setStoredUser(data.user);
      navigate("/feed");
    } catch { setError("Bağlantı hatası"); }
    finally { setLoading(false); }
  };

  const handleRegisterStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regUsername || !regEmail) { setError("Tüm alanları doldurun"); return; }
    if (regUsername.length < 3) { setError("Kullanıcı adı en az 3 karakter olmalı"); return; }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(regEmail)) { setError("Geçerli bir e-posta girin"); return; }
    setError("");
    setView("register-2");
  };

  const handleRegisterStep2 = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regPassword) { setError("Şifre gerekli"); return; }
    if (regPassword.length < 6) { setError("Şifre en az 6 karakter olmalı"); return; }
    if (regPassword !== regPasswordConfirm) { setError("Şifreler eşleşmiyor"); return; }
    setError(""); setLoading(true);
    try {
      const data = await register({
        name: regName,
        username: regUsername,
        email: regEmail,
        password: regPassword,
        birthDate: regBirthDate || undefined,
        city: regCity || undefined,
      });
      if (data.error) { setError(data.error); return; }
      if (data.requiresEmailVerification) {
        setTempToken(data.tempToken);
        setView("email-verify");
        return;
      }
      if (data.token) {
        setToken(data.token);
        if (data.refreshToken) setRefreshToken(data.refreshToken);
        if (data.user) setStoredUser(data.user);
        navigate("/feed");
      }
    } catch { setError("Bağlantı hatası"); }
    finally { setLoading(false); }
  };

  const handle2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode) { setError("Doğrulama kodunu girin"); return; }
    setError(""); setLoading(true);
    try {
      const data = await verify2FA(tempToken, otpCode);
      if (data.error) { setError(data.error); return; }
      setToken(data.token || data.accessToken);
      if (data.refreshToken) setRefreshToken(data.refreshToken);
      if (data.user) setStoredUser(data.user);
      navigate("/feed");
    } catch { setError("Bağlantı hatası"); }
    finally { setLoading(false); }
  };

  const handleEmailVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode) { setError("Doğrulama kodunu girin"); return; }
    setError(""); setLoading(true);
    try {
      const data = await verifyEmailCode(tempToken, otpCode);
      if (data.error) { setError(data.error); return; }
      setToken(data.token);
      if (data.refreshToken) setRefreshToken(data.refreshToken);
      if (data.user) setStoredUser(data.user);
      navigate("/feed");
    } catch { setError("Bağlantı hatası"); }
    finally { setLoading(false); }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) { setError("E-posta adresinizi girin"); return; }
    setError(""); setLoading(true);
    try {
      const data = await forgotPassword(forgotEmail);
      if (data.error) { setError(data.error); return; }
      setForgotSent(true);
    } catch { setError("Bağlantı hatası"); }
    finally { setLoading(false); }
  };

  const inputClass = "w-full px-4 py-3 rounded-xl bg-muted border border-border text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all text-sm";

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-background">
      <div className="w-full max-w-sm animate-scale-in">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 rounded-2xl agro-gradient flex items-center justify-center mb-4 shadow-agro">
            <Sprout className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-extrabold agro-gradient-text">Agro Sosyal</h1>
          <p className="text-muted-foreground text-sm mt-1">Tarım topluluğuyla bağlan</p>
        </div>

        <div className="bg-card rounded-2xl p-6 border border-border shadow-lg">
          {/* LOGIN */}
          {view === "login" && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">E-posta veya Kullanıcı Adı</label>
                <input type="text" value={identifier} onChange={(e) => setIdentifier(e.target.value)} className={inputClass} placeholder="kullanici@example.com" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Şifre</label>
                <div className="relative">
                  <input type={showPw ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} className={inputClass} placeholder="••••••••" />
                  <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              {error && <p className="text-destructive text-xs text-center animate-fade-in">{error}</p>}
              <button type="submit" disabled={loading} className="w-full py-3 rounded-xl agro-gradient text-primary-foreground font-semibold text-sm active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-agro">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Giriş Yap
              </button>
              <button type="button" onClick={() => { setError(""); setView("forgot"); }} className="w-full text-xs text-muted-foreground hover:text-primary transition-colors">
                Şifremi Unuttum
              </button>
              <div className="border-t border-border pt-4">
                <button type="button" onClick={() => { setError(""); setView("register-1"); }} className="w-full py-3 rounded-xl border border-primary text-primary font-semibold text-sm hover:bg-primary/10 transition-all">
                  Hesap Oluştur
                </button>
              </div>
            </form>
          )}

          {/* REGISTER STEP 1 */}
          {view === "register-1" && (
            <form onSubmit={handleRegisterStep1} className="space-y-4">
              <button type="button" onClick={() => { setError(""); setView("login"); }} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-2">
                <ArrowLeft className="w-4 h-4" /> Geri
              </button>
              <h2 className="text-lg font-bold text-foreground">Hesap Oluştur</h2>
              <p className="text-xs text-muted-foreground">Adım 1/2 — Kişisel Bilgiler</p>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Ad Soyad</label>
                <input type="text" value={regName} onChange={(e) => setRegName(e.target.value)} className={inputClass} placeholder="Mehmet Yılmaz" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Kullanıcı Adı</label>
                <input type="text" value={regUsername} onChange={(e) => setRegUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))} className={inputClass} placeholder="mehmetyilmaz" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">E-posta</label>
                <input type="email" value={regEmail} onChange={(e) => setRegEmail(e.target.value)} className={inputClass} placeholder="mehmet@example.com" />
              </div>
              {error && <p className="text-destructive text-xs text-center animate-fade-in">{error}</p>}
              <button type="submit" className="w-full py-3 rounded-xl agro-gradient text-primary-foreground font-semibold text-sm active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-agro">
                Devam Et <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* REGISTER STEP 2 */}
          {view === "register-2" && (
            <form onSubmit={handleRegisterStep2} className="space-y-4">
              <button type="button" onClick={() => { setError(""); setView("register-1"); }} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-2">
                <ArrowLeft className="w-4 h-4" /> Geri
              </button>
              <h2 className="text-lg font-bold text-foreground">Hesap Oluştur</h2>
              <p className="text-xs text-muted-foreground">Adım 2/2 — Güvenlik</p>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Şifre</label>
                <input type="password" value={regPassword} onChange={(e) => setRegPassword(e.target.value)} className={inputClass} placeholder="En az 6 karakter" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Şifre Tekrar</label>
                <input type="password" value={regPasswordConfirm} onChange={(e) => setRegPasswordConfirm(e.target.value)} className={inputClass} placeholder="Şifreyi tekrar girin" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Doğum Tarihi (isteğe bağlı)</label>
                <input type="date" value={regBirthDate} onChange={(e) => setRegBirthDate(e.target.value)} className={inputClass} />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Şehir (isteğe bağlı)</label>
                <input type="text" value={regCity} onChange={(e) => setRegCity(e.target.value)} className={inputClass} placeholder="İstanbul" />
              </div>
              {error && <p className="text-destructive text-xs text-center animate-fade-in">{error}</p>}
              <button type="submit" disabled={loading} className="w-full py-3 rounded-xl agro-gradient text-primary-foreground font-semibold text-sm active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-agro">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Kayıt Ol
              </button>
            </form>
          )}

          {/* 2FA */}
          {view === "2fa" && (
            <form onSubmit={handle2FA} className="space-y-4">
              <h2 className="text-lg font-bold text-foreground text-center">İki Adımlı Doğrulama</h2>
              <p className="text-xs text-muted-foreground text-center">E-postanıza gönderilen 6 haneli kodu girin</p>
              <input
                type="text" maxLength={6} value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))}
                className="w-full px-4 py-4 rounded-xl bg-muted border border-border text-foreground text-center text-2xl tracking-[0.5em] font-bold placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                placeholder="000000"
              />
              {error && <p className="text-destructive text-xs text-center animate-fade-in">{error}</p>}
              <button type="submit" disabled={loading} className="w-full py-3 rounded-xl agro-gradient text-primary-foreground font-semibold text-sm active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-agro">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Doğrula
              </button>
              <button type="button" onClick={() => { setView("login"); setError(""); setOtpCode(""); }} className="w-full text-sm text-muted-foreground hover:text-foreground">← Geri dön</button>
            </form>
          )}

          {/* EMAIL VERIFY */}
          {view === "email-verify" && (
            <form onSubmit={handleEmailVerify} className="space-y-4">
              <h2 className="text-lg font-bold text-foreground text-center">E-posta Doğrulama</h2>
              <p className="text-xs text-muted-foreground text-center">{regEmail} adresine gönderilen kodu girin</p>
              <input
                type="text" maxLength={6} value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))}
                className="w-full px-4 py-4 rounded-xl bg-muted border border-border text-foreground text-center text-2xl tracking-[0.5em] font-bold placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                placeholder="000000"
              />
              {error && <p className="text-destructive text-xs text-center animate-fade-in">{error}</p>}
              <button type="submit" disabled={loading} className="w-full py-3 rounded-xl agro-gradient text-primary-foreground font-semibold text-sm active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-agro">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Doğrula ve Kaydı Tamamla
              </button>
            </form>
          )}

          {/* FORGOT PASSWORD */}
          {view === "forgot" && (
            <form onSubmit={handleForgot} className="space-y-4">
              <button type="button" onClick={() => { setError(""); setForgotSent(false); setView("login"); }} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-2">
                <ArrowLeft className="w-4 h-4" /> Geri
              </button>
              <h2 className="text-lg font-bold text-foreground">Şifremi Unuttum</h2>
              {forgotSent ? (
                <div className="text-center space-y-3">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                    <span className="text-3xl">📧</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Şifre sıfırlama bağlantısı e-postanıza gönderildi.</p>
                </div>
              ) : (
                <>
                  <p className="text-xs text-muted-foreground">Kayıtlı e-posta adresinizi girin</p>
                  <input type="email" value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)} className={inputClass} placeholder="mehmet@example.com" />
                  {error && <p className="text-destructive text-xs text-center animate-fade-in">{error}</p>}
                  <button type="submit" disabled={loading} className="w-full py-3 rounded-xl agro-gradient text-primary-foreground font-semibold text-sm active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-agro">
                    {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                    Sıfırlama Linki Gönder
                  </button>
                </>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
