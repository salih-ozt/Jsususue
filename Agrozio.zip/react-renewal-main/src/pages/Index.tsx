import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { isAuthenticated } from "@/lib/api";
import SplashScreen from "@/components/SplashScreen";

const Index = () => {
  const navigate = useNavigate();
  const [showSplash, setShowSplash] = useState(true);

  const handleSplashComplete = useCallback(() => {
    setShowSplash(false);
    if (isAuthenticated()) {
      navigate("/feed", { replace: true });
    } else {
      navigate("/login", { replace: true });
    }
  }, [navigate]);

  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  return null;
};

export default Index;
