import { useEffect, useState, useCallback } from "react";
import { Sprout, Loader2, MessageCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import PostCard from "@/components/PostCard";
import BottomNav from "@/components/BottomNav";
import StoriesBar from "@/components/StoriesBar";
import { getFeed } from "@/lib/api";

const FeedPage = () => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<any[]>([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);

  const loadFeed = useCallback(async (p: number) => {
    try {
      setLoading(true);
      const data = await getFeed(p);
      const newPosts = data.posts || [];
      if (p === 1) setPosts(newPosts);
      else setPosts((prev) => [...prev, ...newPosts]);
      setHasMore(newPosts.length >= 20);
    } catch {}
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadFeed(1); }, [loadFeed]);

  const loadMore = () => {
    if (!loading && hasMore) {
      const next = page + 1;
      setPage(next);
      loadFeed(next);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 glass border-b border-border">
        <div className="max-w-lg mx-auto flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-2">
            <Sprout className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-extrabold agro-gradient-text tracking-tight">Agro Sosyal</h1>
          </div>
          <button onClick={() => navigate("/chat")} className="relative text-muted-foreground hover:text-foreground transition-colors">
            <MessageCircle className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Stories */}
      <div className="max-w-lg mx-auto border-b border-border">
        <StoriesBar />
      </div>

      <main className="max-w-lg mx-auto px-4 py-4 space-y-4">
        {loading && posts.length === 0 ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-20 space-y-3">
            <Sprout className="w-12 h-12 text-muted-foreground mx-auto" />
            <p className="text-muted-foreground">Henüz gönderi yok</p>
            <p className="text-xs text-muted-foreground">Birilerini takip ederek akışınızı doldurun!</p>
          </div>
        ) : (
          <>
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
            {hasMore && (
              <button onClick={loadMore} disabled={loading} className="w-full py-3 text-sm text-primary font-medium disabled:opacity-50">
                {loading ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : "Daha fazla yükle"}
              </button>
            )}
          </>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default FeedPage;
