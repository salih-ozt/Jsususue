import { useState, useEffect, useRef } from "react";
import { Send, ArrowLeft, Loader2, Search } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { getConversations, getMessages, sendMessage, getStoredUser } from "@/lib/api";

const ChatPage = () => {
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeChat, setActiveChat] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const currentUser = getStoredUser();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { loadConversations(); }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const loadConversations = async () => {
    setLoading(true);
    try {
      const data = await getConversations();
      setConversations(data.conversations || []);
    } catch {}
    setLoading(false);
  };

  const openChat = async (conv: any) => {
    setActiveChat(conv);
    try {
      const data = await getMessages(conv.partner?.id || conv.partner_id);
      setMessages(data.messages || []);
    } catch {}
  };

  const handleSend = async () => {
    if (!input.trim() || sending) return;
    const partnerId = activeChat?.partner?.id || activeChat?.partner_id;
    if (!partnerId) return;
    const text = input.trim();
    setInput("");
    setSending(true);
    setMessages((prev) => [...prev, { id: `temp-${Date.now()}`, senderId: currentUser?.id, content: text, createdAt: new Date().toISOString() }]);
    try { await sendMessage(partnerId, text); } catch {}
    setSending(false);
  };

  const filteredConvs = conversations.filter((c) => {
    if (!searchQuery) return true;
    const name = (c.partner?.name || c.partner?.username || "").toLowerCase();
    return name.includes(searchQuery.toLowerCase());
  });

  // Active chat view
  if (activeChat) {
    const partner = activeChat.partner;
    const partnerAvatar = partner?.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${partner?.username || "u"}&backgroundColor=0a1628`;

    return (
      <div className="min-h-screen bg-background flex flex-col">
        <header className="sticky top-0 z-40 glass border-b border-border">
          <div className="max-w-lg mx-auto flex items-center gap-3 h-14 px-4">
            <button onClick={() => setActiveChat(null)} className="active:scale-90 transition-transform">
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </button>
            <img src={partnerAvatar} alt="" className="w-8 h-8 rounded-full object-cover" />
            <div>
              <p className="font-semibold text-sm text-foreground">{partner?.name || partner?.username}</p>
              {partner?.isOnline && <p className="text-[10px] text-primary">Çevrimiçi</p>}
            </div>
          </div>
        </header>

        <main className="flex-1 max-w-lg mx-auto w-full px-4 py-4 space-y-3 overflow-y-auto scrollbar-hide pb-24">
          {messages.map((msg) => {
            const isMe = msg.senderId === currentUser?.id;
            return (
              <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"} animate-fade-in`}>
                <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${
                  isMe ? "agro-gradient text-primary-foreground rounded-br-md" : "bg-secondary text-secondary-foreground rounded-bl-md"
                }`}>
                  <p>{msg.content}</p>
                  <p className={`text-[10px] mt-1 ${isMe ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                    {new Date(msg.createdAt).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </main>

        <div className="fixed bottom-0 left-0 right-0 glass border-t border-border p-3">
          <div className="max-w-lg mx-auto flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Mesaj yaz..."
              className="flex-1 px-4 py-3 rounded-xl bg-muted border border-border text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm"
            />
            <button onClick={handleSend} className="w-10 h-10 rounded-xl agro-gradient flex items-center justify-center active:scale-95 transition-transform shadow-agro">
              <Send className="w-4 h-4 text-primary-foreground" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Conversations list
  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 glass border-b border-border">
        <div className="max-w-lg mx-auto px-4 py-3 space-y-3">
          <h1 className="text-lg font-bold text-foreground">Mesajlar</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Sohbet ara..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-muted border border-border text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm"
            />
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filteredConvs.length === 0 ? (
          <div className="text-center py-20 space-y-3">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto">
              <span className="text-3xl">💬</span>
            </div>
            <p className="text-muted-foreground text-sm">Henüz mesaj yok</p>
          </div>
        ) : (
          filteredConvs.map((conv) => {
            const partner = conv.partner;
            const avatar = partner?.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${partner?.username || "u"}&backgroundColor=0a1628`;
            return (
              <button
                key={conv.partner_id || partner?.id}
                onClick={() => openChat(conv)}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-secondary/50 transition-colors"
              >
                <div className="relative">
                  <img src={avatar} alt="" className="w-12 h-12 rounded-full object-cover" />
                  {(conv.isOnline || conv.online) && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-primary rounded-full border-2 border-card" />
                  )}
                </div>
                <div className="flex-1 text-left min-w-0">
                  <p className="text-sm font-semibold text-foreground">{partner?.name || partner?.username}</p>
                  <p className="text-xs text-muted-foreground truncate">{conv.content}</p>
                </div>
                {conv.unreadCount > 0 && (
                  <span className="w-5 h-5 rounded-full agro-gradient text-primary-foreground text-[10px] font-bold flex items-center justify-center">
                    {conv.unreadCount}
                  </span>
                )}
              </button>
            );
          })
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default ChatPage;
