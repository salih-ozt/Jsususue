import { useEffect, useState } from "react";
import { Loader2, Heart, MessageCircle, UserPlus, AtSign } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { getNotifications, markNotificationsRead } from "@/lib/api";

const iconMap: Record<string, any> = {
  like: Heart,
  comment: MessageCircle,
  follow: UserPlus,
  mention: AtSign,
};

const NotificationsPage = () => {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    try {
      const data = await getNotifications();
      setNotifications(data.notifications || []);
    } catch {}
    setLoading(false);
  };

  const handleMarkAllRead = async () => {
    try {
      await markNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    } catch {}
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 glass border-b border-border">
        <div className="max-w-lg mx-auto flex items-center justify-between h-14 px-4">
          <h1 className="text-lg font-bold text-foreground">Bildirimler</h1>
          {unreadCount > 0 && (
            <button onClick={handleMarkAllRead} className="text-xs text-primary font-bold">
              Tümünü Okundu Yap
            </button>
          )}
        </div>
      </header>

      <main className="max-w-lg mx-auto">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-20 space-y-3">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto">
              <span className="text-3xl">🔔</span>
            </div>
            <p className="text-muted-foreground text-sm">Henüz bildirim yok</p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {notifications.map((notif) => {
              const Icon = iconMap[notif.type] || Heart;
              const avatar = notif.fromProfilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${notif.fromUsername || "u"}&backgroundColor=0a1628`;
              return (
                <div
                  key={notif.id}
                  className={`flex items-start gap-3 px-4 py-3 transition-colors ${
                    !notif.read ? "bg-primary/5" : ""
                  }`}
                >
                  <div className="relative flex-shrink-0">
                    <img src={avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-card flex items-center justify-center">
                      <Icon className="w-3 h-3 text-primary" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground">
                      <span className="font-semibold">{notif.fromUsername || notif.fromName}</span>{" "}
                      <span className="text-muted-foreground">{notif.message || getNotifText(notif.type)}</span>
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">{formatTimeAgo(notif.createdAt)}</p>
                  </div>
                  {!notif.read && (
                    <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0 mt-2" />
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

function getNotifText(type: string): string {
  switch (type) {
    case "like": return "gönderini beğendi";
    case "comment": return "gönderine yorum yaptı";
    case "follow": return "seni takip etmeye başladı";
    case "mention": return "senden bahsetti";
    default: return "bir etkinlik gerçekleşti";
  }
}

function formatTimeAgo(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
  if (diff < 60) return "az önce";
  if (diff < 3600) return `${Math.floor(diff / 60)}dk`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}sa`;
  return `${Math.floor(diff / 86400)}g`;
}

export default NotificationsPage;
