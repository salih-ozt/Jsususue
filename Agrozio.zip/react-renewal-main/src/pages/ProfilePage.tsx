import { useEffect, useState } from "react";
import { Settings, Loader2, LogOut, Grid3x3, Bookmark, Film, Camera } from "lucide-react";
import { useNavigate } from "react-router-dom";
import BottomNav from "@/components/BottomNav";
import EditProfileModal from "@/components/EditProfileModal";
import { getMe, getUserPosts, logout as apiLogout } from "@/lib/api";

type ProfileTab = "posts" | "photos" | "videos" | "saved";

const ProfilePage = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ProfileTab>("posts");
  const [showEditModal, setShowEditModal] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const meData = await getMe();
        const u = meData.user;
        setUser(u);
        if (u?.id) {
          const p = await getUserPosts(u.id);
          setPosts(p.posts || []);
        }
      } catch {
        navigate("/login");
      } finally {
        setLoading(false);
      }
    })();
  }, [navigate]);

  const handleLogout = async () => {
    await apiLogout();
    navigate("/login");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) return null;

  const avatar = user.profilePic || `https://api.dicebear.com/7.x/thumbs/svg?seed=${user.username}&backgroundColor=0a1628`;

  const filteredPosts = posts.filter((p) => {
    if (activeTab === "photos") return p.mediaType === "image" || (!p.mediaType && (p.mediaUrl || p.media));
    if (activeTab === "videos") return p.mediaType === "video";
    return true;
  });

  const tabs: { key: ProfileTab; icon: any; label: string }[] = [
    { key: "posts", icon: Grid3x3, label: "Gönderi" },
    { key: "photos", icon: Camera, label: "Fotoğraf" },
    { key: "videos", icon: Film, label: "Video" },
    { key: "saved", icon: Bookmark, label: "Kayıtlı" },
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 glass border-b border-border">
        <div className="max-w-lg mx-auto flex items-center justify-between h-14 px-4">
          <h1 className="text-lg font-bold text-foreground">{user.username}</h1>
          <div className="flex items-center gap-3">
            <button onClick={handleLogout} className="text-muted-foreground hover:text-destructive transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
            <button className="text-muted-foreground hover:text-foreground transition-colors">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6">
        {/* Profile header */}
        <div className="flex items-center gap-6 mb-6">
          <div className="relative">
            <img src={avatar} alt={user.username} className="w-20 h-20 rounded-full object-cover ring-2 ring-primary/40" />
          </div>
          <div className="flex-1 flex justify-around text-center">
            <div>
              <p className="text-lg font-bold text-foreground">{user.postCount ?? 0}</p>
              <p className="text-xs text-muted-foreground">Gönderi</p>
            </div>
            <div>
              <p className="text-lg font-bold text-foreground">{(user.followerCount ?? 0).toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Takipçi</p>
            </div>
            <div>
              <p className="text-lg font-bold text-foreground">{user.followingCount ?? 0}</p>
              <p className="text-xs text-muted-foreground">Takip</p>
            </div>
          </div>
        </div>

        <p className="text-sm text-foreground mb-1 font-semibold">{user.name || user.username}</p>
        {user.bio && <p className="text-sm text-muted-foreground mb-1">{user.bio}</p>}
        {user.city && <p className="text-xs text-muted-foreground mb-4">📍 {user.city}</p>}

        <button
          onClick={() => setShowEditModal(true)}
          className="w-full py-2.5 rounded-xl bg-secondary text-secondary-foreground text-sm font-semibold hover:brightness-110 transition-all mb-6"
        >
          Profili Düzenle
        </button>

        {/* Tabs */}
        <div className="flex border-b border-border mb-4">
          {tabs.map(({ key, icon: Icon, label }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex-1 flex flex-col items-center gap-1 py-3 text-xs font-medium transition-colors relative ${
                activeTab === key ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{label}</span>
              {activeTab === key && (
                <div className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-primary rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* Posts grid */}
        <div className="grid grid-cols-3 gap-0.5 rounded-xl overflow-hidden">
          {filteredPosts.map((post) => {
            const img = post.mediaUrl || post.media;
            if (!img || post.mediaType === "text") return null;
            return (
              <img
                key={post.id}
                src={img}
                alt=""
                className="aspect-square object-cover hover:opacity-80 transition-opacity cursor-pointer"
              />
            );
          })}
        </div>
        {filteredPosts.length === 0 && (
          <p className="text-center text-muted-foreground py-10 text-sm">Henüz içerik yok</p>
        )}
      </main>

      <BottomNav />

      <EditProfileModal
        user={user}
        open={showEditModal}
        onClose={() => setShowEditModal(false)}
        onUpdated={(updated) => setUser({ ...user, ...updated })}
      />
    </div>
  );
};

export default ProfilePage;
